_list = ["the", "dead", "parrot", "sketch"]
parrot = _list

for i in parrot:
    print(f"{i.capitalize()} {len(i)}")