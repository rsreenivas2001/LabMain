x = int(input("Enter a Number: "))

print(x+(10*x+x)+(100*x+10*x+x)+(1000*x+100*x+10*x+x))