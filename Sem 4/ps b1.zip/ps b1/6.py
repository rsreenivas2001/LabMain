x = int(input("Enter N : "))
d = {}
for i in range(1, x+1):
    d[i] = pow(i, 2)

print(d)
