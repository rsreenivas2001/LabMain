
colors = {'white','red','blue','green'}

colors.remove('red')
print(colors)
if 'yellow' in colors:
    print('Yes')
else:
    print('No')