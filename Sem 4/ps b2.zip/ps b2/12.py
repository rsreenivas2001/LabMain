arr1 = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
arr2 = [i for i in arr1 if i % 2 == 0]

print(arr1, "\n", arr2)