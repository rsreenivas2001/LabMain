x = [12,24,35,24,88,120,155]

new_x = [i for i in x if i != 24]

print(new_x)