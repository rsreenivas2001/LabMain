#include<stdio.h>
#include<string.h>
void main()
{
    int i,l=0,u=0,sc=0,n=0;
    char s[100];
    printf("Enter the string\n");
    scanf("%[^\n]s",s);
    for(i=0;s[i]!='\0';i++)
    {

        if(islower(s[i]))
           l++;
        if(isupper(s[i]))
           u++;
        if(isdigit(s[i]))
           n++;
    }
    sc=strlen(s)-l-u-n;
    printf("\nNumber of uppercase : %d",u);
    printf("\nNumber of lowercase : %d",l);
    printf("\nNumber of spec.char : %d",sc);
}
