#include<stdio.h>
#include<string.h>

void main()
{
    int i;
    char s[100];
    printf("Enter the string\n");
    scanf("%[^\n]s",s);
    printf("\nThe enetered string is\n");
    printf("%s",s);
    printf("\nThe enetered string in uppercase is\n");
    printf("%s",strupr(s));
    printf("\nThe enetered string in lowercase is\n");
    printf("%s",strlwr(s));
}
